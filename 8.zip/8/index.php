<?php

$trenutnaGodina = date("Y");

$osobe = [

    "Teodora
     => [

        "ime" => "Teodora",
        "prezime" => "Mihajlović",
        "godiste" => 1995,
        "dosije" => "2018/55"
    ], 

    
    "Nikola" => [

        "ime" => "Nikola",
        "prezime" => "Stojković",
        "godiste" => 1993,
        "dosije" => "2019/34"
    ], 
    
    "Andrijana" => [

        "ime" => "Andrijana",
        "prezime" => "Cupković",
        "godiste" => 1997,
        "dosije" => "2019/99"
    ], 
    
    "Maša" => [

        "ime" => "Maša",
        "prezime" => "Radulović",
        "godiste" => 1996,
        "dosije" => "2022/66"
    ], 
  

];

foreach($osobe as $osoba => $informacije )
{
$ime = $informacije["ime"];   
$prezime = $informacije["prezime"];  
$godine = $trenutnaGodina-$informacije["godiste"];
$dosije = $informacije["dosije"];


echo $informacije["prezime"];





}





?>