<?php


$data = [

    "folder" => [

        "main"    => "Glavna",
        "about" => "O nama",
        "contact" => "Kontakt",
        
    ],


];







?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>#8 foreach unutar HTML-a</title>
</head>
<body>


    <?php foreach($data as $file => $info): ?>

         <nav>
             <a href="domaci.php"><?= $info["main"]; ?></a>
             <a href="about_us.php"><?= $info["about"];?></a>
             <a href="contact.php"><?= $info["contact"];?></a>
         </nav>
    
    <?php endforeach;?>
    
    
</body>
</html>